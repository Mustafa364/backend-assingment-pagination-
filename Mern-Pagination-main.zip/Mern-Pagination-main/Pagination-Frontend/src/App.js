import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AppRouter from './Config/Approuter';

function App() {
  return (
   <>
   <AppRouter/>
   </>
  );
}

export default App;
