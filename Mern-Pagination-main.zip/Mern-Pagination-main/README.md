# Mern Pagination

# First Page
![image](https://github.com/Azhar999-hub/Mern-Pagination/assets/80776210/f16a597c-39ae-4c41-91d9-7ccaa0fc2ad9)

# Second Page
![image](https://github.com/Azhar999-hub/Mern-Pagination/assets/80776210/7031ba88-4843-4be0-a597-99f56befef6b)

# Third Page
![image](https://github.com/Azhar999-hub/Mern-Pagination/assets/80776210/d7691cdb-c07d-4d6e-8210-a5543247f6b5)

# Fourth Page
![image](https://github.com/Azhar999-hub/Mern-Pagination/assets/80776210/7dce0eab-bd04-45e2-a25c-6edc5ce77a1d)

# Fifth Page
![image](https://github.com/Azhar999-hub/Mern-Pagination/assets/80776210/6f0ce7f3-8bb7-4d05-acb3-0054a5791ca2)
